﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using Microsoft.VisualBasic;
using System.Media;
using WMPLib;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Runtime.InteropServices;
using TextBox = System.Windows.Forms.TextBox;
using Button = System.Windows.Forms.Button;
using ComboBox = System.Windows.Forms.ComboBox;
using System.Threading;

namespace WindowsFormsApp1 {
    
    public partial class Form1 : Form {
        RadioButton DS_VF;
        RadioButton DS_3Dformat;
        RadioButton DS_OutputCodec;
        RadioButton filtr;
        RadioButton DS_Wii;
        RadioButton Wii_TV;
        RadioButton Wii_framerate;
        RadioButton Wii_codec;
        RadioButton stretch;
        RadioButton Wii_Aspect;
        SoundPlayer chordsound = new SoundPlayer();
        SoundPlayer exclamationsound = new SoundPlayer();
        SoundPlayer tadasound = new SoundPlayer();
        SoundPlayer logonsound = new SoundPlayer();
        SoundPlayer commandsound = new SoundPlayer();
        Process ffmpeg = new Process();
        WindowsMediaPlayer player = new WindowsMediaPlayer();
        string verze = "1.2.0";
        string vstup;
        string vstup2;
        string cesta;
        string outputnazev;
        public Form1() {
            InitializeComponent();
            version.Text = verze;
            if(File.Exists(@"C:\Windows\Media\Windows Logon Sound.wav")) {
                logonsound.SoundLocation = @"C:\Windows\Media\Windows Logon Sound.wav";
            }
            if(File.Exists(@"C:\Windows\Media\Windows Menu Command.wav")) {
                commandsound.SoundLocation = @"C:\Windows\Media\Windows Menu Command.wav";
            }
            if(File.Exists(@"C:\Windows\Media\chord.wav")) {
                chordsound.SoundLocation = @"C:\Windows\Media\chord.wav";
            }
            if(File.Exists(@"C:\Windows\Media\Windows Exclamation.wav")) {
                exclamationsound.SoundLocation = @"C:\Windows\Media\Windows Exclamation.wav";
            }
            if(File.Exists(@"C:\Windows\Media\tada.wav")) {
                tadasound.SoundLocation = @"C:\Windows\Media\tada.wav";
            }
            SoundPlayer testsound = new SoundPlayer();
            logonsound.Play();
            textBox2.SetWatermark("custom bitrate (in Kb/s)");
        }
        public static void ScaleResolution(int sourceWidth, int sourceHeight, int targetWidth, int targetHeight, out int scaledWidth, out int scaledHeight, float percent, out int actualpercent) {
            //get source aspect
            double scaleX = (double)targetWidth / sourceWidth;
            double scaleY = (double)targetHeight / sourceHeight;
            //get whichever aspect is smaller
            double scale = Math.Min(scaleX, scaleY);
            //get variable for temp scale of Y, in case the resolution wants to get scalled vertically with the percent
            double skaledy;
            //get the new vertical resolution
            double scaledY = sourceHeight * scale;
        woomy:;
            //if percent is larger than 0, then scale the resolution vertically. if its larger than the maximum y, then it decreases the percent and tries again until it fits
            if(percent > 0) {
                skaledy = scaledY + (scaledY / 100 * percent);
                percent -= (float)0.1;
                if(skaledy > targetHeight) goto woomy;
                actualpercent = (int)percent;
            }
            //if percent is 0, use the normal scale
            else {
                skaledy = scaledY;
                actualpercent = 0;
            }
            scaledY = skaledy;
            scaledWidth = (int)Math.Round(sourceWidth * scale);
            scaledHeight = (int)Math.Round(scaledY);
            if(scaledWidth % 2 == 1) {
                scaledWidth++;
                if(scaledWidth > targetWidth) {
                    scaledWidth -= 2;
                }
            }
            if(scaledHeight % 2 == 1) {
                scaledHeight++;
                if(scaledHeight > targetHeight) {
                    scaledHeight -= 2;
                }
            }
        }
        private void message_error(string zprava) {
            chordsound.Play();
            MessageBox.Show(zprava, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private int message_prompt(string zprava) {
            exclamationsound.Play();
            DialogResult dialogResult = MessageBox.Show(zprava, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            woomy:
            if(dialogResult == DialogResult.Yes) {
                return 1;
            }
            else if(dialogResult == DialogResult.No) {
                return 0;
            }
            else {
                exclamationsound.Play();
                dialogResult = MessageBox.Show(zprava, "ANSWER!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                goto woomy;
            }
        }
        private int message_prompt2(string zprava) {
            exclamationsound.Play();
            DialogResult dialogResult = MessageBox.Show(zprava, "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
        woomy:
            if(dialogResult == DialogResult.OK) {
                return 1;
            }
            else if(dialogResult == DialogResult.Cancel) {
                return 0;
            }
            else {
                exclamationsound.Play();
                dialogResult = MessageBox.Show(zprava, "ANSWER!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                goto woomy;
            }
        }
        private void woomy(object sender, EventArgs e) {
            convert(null, null);
        }
        //private async void convert(object sender, EventArgs e, ManualResetEvent handle) {
        private async void convert(object sender, EventArgs e) {
            Enabled = false;
            if(true) {
                DS_Wii = this.panel_ds_or_wii.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();

                DS_VF = this.panel_ds_vf.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();
                DS_3Dformat = this.panel_ds_leftright.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();
                DS_OutputCodec = this.panel_ds_outcodec.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();

                Wii_TV = this.panel_wii_tv_out.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();
                Wii_Aspect = this.panel_wii_aspect.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();
                Wii_framerate = this.panel_wii_fps.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();
                Wii_codec = this.wii_output_codec.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();


                filtr = this.panel_scalefilter.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();
                stretch = this.panel_stretch.Controls.OfType<RadioButton>().Where(x => x.Checked).FirstOrDefault();
            }
            var clip = player.newMedia(vstup);
            player.currentMedia = clip;
            UInt16 duration = 0;
            player.controls.play();
            UInt16 bitrate;
            UInt32 max_bitrate = 0;

            for(uint i = 0; i < 20000000; i++) {
                duration = Convert.ToUInt16(clip.duration);
                if(duration == 0) {
                    if(vstup == null) {
                        message_error("Error: You didnt choose input video!");
                        goto skipaa;
                    }
                    await Task.Delay(100); //<-- kvůli tomuhle řádku to musí být async ta funkce....
                }
                else break;
            }
            UInt16 vstup_vyska = Convert.ToUInt16(player.currentMedia.imageSourceHeight);
            UInt16 vstup_sirka = Convert.ToUInt16(player.currentMedia.imageSourceWidth);
            if(duration == 0) {
                message_error("Error loading video: duration is detected as 0. Using default bitrate of 2000Kb/s. It might be caused by bad input filename\nYou can specify custom bitrate in the debug menu");
                bitrate = 2000;
                player.controls.stop();
                //goto skipaa;
                max_bitrate = 4000;
                goto bitrateskip;
            }
            UInt32 fourGBinKb = 32000000;
            max_bitrate = fourGBinKb / duration;
        bitrateskip:;
            player.controls.stop();
            string surrounddownmix;
            if(surround.Checked) {
                surrounddownmix = " -af \"pan=stereo|c0=0.5*c2+0.707*c0+0.707*c4+0.5*c3|c1=0.5*c2+0.707*c1+0.707*c5+0.5*c3\" ";
            }
            else surrounddownmix = "";
            if(DS_Wii != null) {
                if(DS_Wii.Name == "Wii3DS_radio_3DS") {
                    string codec = "";
                    int aaa = 4;
                    string argumenty = "";
                    string output = "";
                    string puttogether = "";
                    bool abort = false;
                    if(vstup == null) {
                        message_error("Error: You didnt choose input video!");
                    }
                    if(DS_VF == null) {
                        message_error("Error: You didnt choose output format!");
                        abort = true;
                    }
                    if(DS_3Dformat == null) {
                        if(DS_VF != null) {
                            if(DS_VF.Name == "ds_vf_3d") {
                                message_error("Error: You didnt choose input 3D format!");
                                abort = true;
                            }
                        }
                    }
                    if(DS_OutputCodec == null) {
                        message_error("Error: You didnt choose output codec!");
                        abort = true;
                    }
                    if(filtr == null) {
                        message_error("Error: You didnt choose which scaling filter!");
                        abort = true;
                    }
                    if(stretch == null) {
                        message_error("Error: You didnt choose stretch!");
                        abort = true;
                    }
                    if(abort) goto abortion;
                    switch(DS_VF.Name) {
                        case "ds_vf_standard":
                            aaa = 0;
                            vstup2 = vstup;
                            break;
                        case "ds_vf_horihd":
                            vstup2 = vstup;
                            aaa = 1;
                            break;
                        case "ds_vf_3d":
                            aaa = 2;
                            break;
                        default:
                            break;
                    }
                    if(aaa == 2) switch(DS_3Dformat.Name) {
                            case "ds_3dformat_leftright":
                                vstup2 = vstup;
                                break;
                            case "ds_3dformat_updown":
                                vstup2 = "convertedtoleftright.mkv";
                                ffmpeg.StartInfo.FileName = "cmd.exe";
                                ffmpeg.StartInfo.Arguments = "/k " + "ffmpeg -y -i " + vstup + " -vf stereo3d=abl:sbsl -crf 10 -c:a copy convertedtoleftright.mkv" + " && ping 1.1.1.1  & exit";
                                debug_textbox.Text += "ffmpeg -y -i " + vstup + " -vf stereo3d=abl:sbsl -crf 10 -c:a copy convertedtoleftright.mkv" + " && ping 1.1.1.1  & exit";
                                ffmpeg.Start();
                                ffmpeg.WaitForExit();
                                break;
                            default:
                                break;
                        }
                    switch(DS_OutputCodec.Name) {
                        case "ds_out_h264":
                            codec = "libx264 ";
                            break;
                        case "ds_out_mpeg":
                            codec = "mpeg2video ";
                            break;
                        case "ds_out_mjpeg":
                            codec = "mjpeg -huffman optimal ";
                            break;
                        default:
                            break;
                    }
                    
                    string bframes = "";
                    if(codec == "libx264 ") {
                        if(nobframes.Checked && nodeblock.Checked) {
                            bframes = "-x264opts \"b-pyramid=0:b-adapt=0:no-deblock:bframes=0\" ";
                        }
                        else if(nobframes.Checked && !nodeblock.Checked) {
                            bframes = "-x264opts \"b-pyramid=0:b-adapt=0:bframes=0\" ";
                        }
                        else if(!nobframes.Checked && nodeblock.Checked) {
                            bframes = "-x264opts \"no-deblock\" ";
                        }
                        if(thirty.Checked) {
                            bframes += " -r 30 ";
                        }
                    }
                    if(codec == "libx264 " && DS_VF.Name == "ds_vf_3d") {
                        if(message_prompt2("Video Player 1.5.1 and 1.5.2 has bug with h264 3D video and plays it too fast. \n Use Video Player 1.5.0 or use mpeg2video codec instead.") == 0) {
                            goto skipaa;
                        }
                    }
                    if(DS_VF.Name == "ds_vf_3d" || DS_VF.Name == "ds_vf_horihd") {
                        if(codec == "libx264 ") {
                            if(max_bitrate > 2000) {
                                bitrate = 2000;
                            }
                            else if(max_bitrate > 1000) {
                                bitrate = Convert.ToUInt16(max_bitrate - 100);
                            }
                            else {
                                bitrate = (Convert.ToUInt16(max_bitrate - 100));
                                message_error("bitrate is small, the output quality may be poor");
                            }
                        }
                        else {
                            if(max_bitrate > 4000) {
                                bitrate = 4000;
                            }
                            else if(max_bitrate > 2000) {
                                bitrate = Convert.ToUInt16(max_bitrate - 100);
                            }
                            else {
                                bitrate = (Convert.ToUInt16(max_bitrate - 100));
                                message_error("bitrate is small, the output quality may be poor");
                            }
                        }
                    }
                    else if(DS_VF.Name == "ds_vf_standard") {
                        if(codec == "libx264 ") {
                            if(max_bitrate > 1000) {
                                bitrate = 1000;
                            }
                            else if(max_bitrate > 500) {
                                bitrate = Convert.ToUInt16(max_bitrate - 60);
                            }
                            else {
                                bitrate = (Convert.ToUInt16(max_bitrate - 50));
                                message_error("bitrate is small, the output quality may be poor");
                            }
                        }
                        else {
                            if(max_bitrate > 4000) {
                                bitrate = 4000;
                            }
                            else if(max_bitrate > 2000) {
                                bitrate = Convert.ToUInt16(max_bitrate - 100);
                            }
                            else {
                                bitrate = (Convert.ToUInt16(max_bitrate - 100));
                                message_error("bitrate is small, the output quality may be poor");
                            }
                        }
                    }
                    else {
                        message_error("Unknown error occured when selecting bitrate!");
                        goto abortion;
                    }
                    if(textBox2.Text != null) try {
                            bitrate = Convert.ToUInt16(textBox2.Text);
                        }
                        catch { };      
                    string res_normal = "";
                    string res_double = "";
                    string res_hd = "";
                    string res_hd_double = "";
                    int x;
                    int y;
                    int actualpercent;
                    if(stretch.Name == "stretch_no") {
                        ScaleResolution(vstup_sirka, vstup_vyska, 400, 240, out x, out y, 0, out actualpercent);
                        res_normal = x.ToString() + ":" + y.ToString();
                        res_hd = (2 * x).ToString() + ":" + y.ToString();
                        res_double = (2 * x).ToString() + ":" + (2 * y).ToString();
                        res_hd_double = (4 * x).ToString() + ":" + (2 * y).ToString();
                    }
                    else if(stretch.Name == "stretch_10") {
                        ScaleResolution(vstup_sirka, vstup_vyska, 400, 240, out x, out y, 10, out actualpercent);
                        res_normal = x.ToString() + ":" + y.ToString();
                        res_hd = (2 * x).ToString() + ":" + y.ToString();
                        res_double = (2 * x).ToString() + ":" + (2 * y).ToString();
                        res_hd_double = (4 * x).ToString() + ":" + (2 * y).ToString();
                    }
                    else if(stretch.Name == "stretch_full") {
                        res_normal = "400:240";
                        res_hd = "800:240";
                        res_double = "800:480";
                        res_hd_double = "1600:480";
                    }
                    
                    debug_textbox.Text = "bitrate\t" + bitrate.ToString() + "Kb/s\n";
                    debug_textbox.Text += "maxbitrate\t" + max_bitrate.ToString() + "Kb/s\n";
                    debug_textbox.Text += "duration\t" + duration.ToString() + "s\n";
                    debug_textbox.Text += "height\t" + vstup_vyska.ToString() + "px\n";
                    debug_textbox.Text += "width\t" + vstup_sirka.ToString() + "p\n";
                    debug_textbox.Text += "res_normal\t" + res_normal + "\n";
                    debug_textbox.Text += "res_hd\t" + res_hd + "\n";
                    debug_textbox.Text += "res_double\t" + res_double + "\n";
                    debug_textbox.Text += "bframes:\t" + bframes + "\n";
                    if(DS_VF.Name == "ds_vf_3d") bitrate = (UInt16)(bitrate / 2);
                    
                    if(codec == "libx264 ") {
                        if(aaa == 0) {
                            if(filtr.Name == "scale_linear") {
                                argumenty = " -vf \"scale=" + res_normal + ":flags =lanczos\" -bsf:v \"h264_metadata=sample_aspect_ratio=1\"";
                            }
                            else if(filtr.Name == "scale_nearest") {
                                argumenty = " -vf \"scale=" + res_normal + ":flags=neighbor\" -bsf:v \"h264_metadata=sample_aspect_ratio=1\" ";
                            }
                            else {
                                argumenty = " -vf \"scale=" + res_double + ":flags=lanczos,scale=" + res_normal + ":flags=neighbor\" -bsf:v \"h264_metadata=sample_aspect_ratio=1\" "; //-aspect 40:24
                            }
                            output = " -c:v " + codec + " -b:a 128k" + surrounddownmix + " -c:a aac  -b:v " + bitrate + "k " + bframes;
                        }
                        else if(aaa == 1) {
                            if(filtr.Name == "scale_linear") {
                                argumenty = " -vf \"scale=" + res_hd + ":flags=Lanczos\" -bsf:v \"h264_metadata=sample_aspect_ratio=1/2\" ";
                            }
                            else if(filtr.Name == "scale_nearest") {
                                argumenty = " -vf \"scale=" + res_hd + ":flags=neighbor\" -bsf:v \"h264_metadata=sample_aspect_ratio=1/2\" ";
                            }
                            else {
                                argumenty = " -vf \"scale=" + res_hd_double + ":flags=lanczos,scale=" + res_hd + ":flags=neighbor\" -bsf:v \"h264_metadata=sample_aspect_ratio=1/2\" ";
                            }
                            output = " -c:v " + codec + " -b:a 128k " + surrounddownmix + "-c:a aac -b:v " + bitrate + "k " + bframes;
                        }
                        else if(aaa == 2) {
                            if(filtr.Name == "scale_linear") {
                                argumenty = "-filter_complex \"split[l][r];[l]stereo3d=sbsl:ml[left];[left]scale=" + res_normal + ":flags=lanczos[left];[r]stereo3d=sbsl:mr[right];[right]scale=" + res_normal + ":flags=lanczos[right]\" ";
                            }
                            else if(filtr.Name == "scale_nearest") {
                                argumenty = "-filter_complex \"split[l][r];[l]stereo3d=sbsl:ml[left];[left]scale=" + res_normal + ":flags=neighbor[left];[r]stereo3d=sbsl:mr[right];[right]scale=" + res_normal + ":flags=neighbor[right]\" ";
                            }
                            else {
                                argumenty = "-filter_complex \"split[l][r];[l]stereo3d=sbsl:ml[left];[left]scale=" + res_double + ":flags=lanczos[left];[left]scale=" + res_normal + ":flags=neighbor[left];[r]stereo3d=sbsl:mr[right];[right]scale=" + res_double + ":flags=lanczos[right];[right]scale=" + res_normal + ":flags=neighbor[right]\" ";
                            }
                            output = " -map [left] -map 0:a -c:a aac -b:a 128k  " + surrounddownmix + " -b:v " + bitrate + "k -c:v " + codec + bframes + " -bsf:v \"h264_metadata=sample_aspect_ratio=1\" left.mp4 -map [right] -an -b:v " + bitrate + "k -c:v " + codec + bframes + " -bsf:v \"h264_metadata=sample_aspect_ratio=1\" right.mp4";
                            puttogether = " && ffmpeg -i left.mp4 -i right.mp4 -map 0:v:0 -map 0:a:0 -map 1:v:0 -c:v copy -c:a copy ";
                        }
                    }
                    else {
                        if(aaa == 0) {
                            if(filtr.Name == "scale_linear") {
                                argumenty = " -vf \"scale=" + res_normal + ":flags =lanczos\" ";
                            }
                            else if(filtr.Name == "scale_nearest") {
                                argumenty = " -vf \"scale=" + res_normal + ":flags=neighbor\"  ";
                            }
                            else {
                                argumenty = " -vf \"scale=" + res_double + ":flags=lanczos,scale=" + res_normal + ":flags=neighbor\"  "; //-aspect 40:24
                            }
                            output = " -c:v " + codec + " -b:a 128k  " + surrounddownmix + "-c:a aac  -b:v " + bitrate + "k " + bframes;
                        }
                        else if(aaa == 1) {
                            message_error("HoriHD is h264 only (for now)");
                            goto abortion;
                        }
                        else if(aaa == 2) {
                            if(filtr.Name == "scale_linear") {
                                argumenty = "-filter_complex \"split[l][r];[l]stereo3d=sbsl:ml[left];[left]scale=" + res_normal + ":flags=lanczos[left];[r]stereo3d=sbsl:mr[right];[right]scale=" + res_normal + ":flags=lanczos[right]\" ";
                            }
                            else if(filtr.Name == "scale_nearest") {
                                argumenty = "-filter_complex \"split[l][r];[l]stereo3d=sbsl:ml[left];[left]scale=" + res_normal + ":flags=neighbor[left];[r]stereo3d=sbsl:mr[right];[right]scale=" + res_normal + ":flags=neighbor[right]\" ";
                            }
                            else {
                                argumenty = "-filter_complex \"split[l][r];[l]stereo3d=sbsl:ml[left];[left]scale=" + res_double + ":flags=lanczos[left];[left]scale=" + res_normal + ":flags=neighbor[left];[r]stereo3d=sbsl:mr[right];[right]scale=" + res_double + ":flags=lanczos[right];[right]scale=" + res_normal + ":flags=neighbor[right]\" ";
                            }
                            output = " -map [left] -map 0:a -c:a aac -b:a 128k " + surrounddownmix + " -b:v " + bitrate + "k -c:v " + codec + bframes + " left.mp4 -map [right] -an -b:v " + bitrate + "k -c:v " + codec + bframes + " right.mp4";
                            puttogether = " && ffmpeg -i left.mp4 -i right.mp4 -map 0:v:0 -map 0:a:0 -map 1:v:0 -c:v copy -c:a copy ";
                        }
                    }
                    ffmpeg.StartInfo.FileName = "cmd.exe";
                    ffmpeg.StartInfo.Arguments = "/k " + "ffmpeg -y -i \"" + vstup2 + "\" " + argumenty + output + puttogether + " \"" + cesta + "\\" + outputnazev + ".mp4\" " + "&& ping 1.1.1.1 -n 1 && exit 1" ;
                    debug_textbox.Text += ffmpeg.StartInfo.Arguments;
                    ffmpeg.Start();
                    ffmpeg.WaitForExit();
                    tadasound.Play();
                abortion:;
                }
                else {
                    byte framerate = 0;
                    string codec = "";
                    int aaa = 4;
                    string argumenty = "";
                    string output = "";
                    string puttogether = "";
                    bool abort = false;
                    if(vstup == null) {
                        message_error("Error: You didnt choose input video!");
                        abort = true;
                    }
                    if(Wii_TV == null) {
                        message_error("Error: You didnt choose output video!");
                        abort = true;
                    }
                    if(Wii_framerate == null) {
                        message_error("Error: You didnt choose framerate!");
                        abort = true;
                    }
                    if(Wii_codec == null) {
                        message_error("Error: You didnt choose codec!");
                        abort = true;
                    }
                    if(abort == true) goto skipaa;

                    switch(Wii_codec.Name) {
                        case "wii_h263":
                            codec = "h263p";
                            break;
                        case "wii_xvid":
                            codec = "xvid";
                            break;
                        case "wii_mjpeg":
                            codec = "mjpeg";
                            break;
                    }

                    string res = "";
                    string res_double = "";
                    UInt16 vyska;
                    UInt16 sirka;
                    if(stretch.Name == "stretch_no") {
                        if(Wii_TV.Name == "w480p") {
                            if(Wii_Aspect.Name == "wii_43") {
                                vyska = (UInt16)((vstup_vyska * 640) / vstup_sirka);
                                if(vstup_vyska <= 480) {
                                    res = "640:-1";
                                    res_double = "1280:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 480) / vstup_vyska);
                                    res = sirka + ":480";
                                    res_double = sirka * 2 + ":480";
                                }
                            }
                            else if(Wii_Aspect.Name == "wii_169") {
                                vyska = (UInt16)((vstup_vyska * 720) / vstup_sirka);
                                if(vstup_vyska <= 480) {
                                    res = "720:-1";
                                    res_double = "1440:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 480) / vstup_vyska);
                                    res = sirka + ":480";
                                    res_double = sirka * 2 + ":480";
                                }
                            }
                            else {
                                message_error("error occured at wii 480p aspect, no stretch");
                                goto exitttttt;
                            }
                        }
                        else if(Wii_TV.Name == "w576p") {
                            if(Wii_Aspect.Name == "wii_43") {
                                vyska = (UInt16)((vstup_vyska * 640) / vstup_sirka);
                                if(vstup_vyska <= 576) {
                                    res = "640:-1";
                                    res_double = "1280:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 576) / vstup_vyska);
                                    res = sirka + ":576";
                                    res_double = sirka * 2 + ":576";
                                }
                            }
                            else if(Wii_Aspect.Name == "wii_169") {
                                vyska = (UInt16)((vstup_vyska * 720) / vstup_sirka);
                                if(vstup_vyska <= 576) {
                                    res = "720:-1";
                                    res_double = "1440:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 576) / vstup_vyska);
                                    res = sirka + ":576";
                                    res_double = sirka * 2 + ":576";
                                }
                            }
                            else {
                                message_error("error occured at wii 576i aspect, no stretch");
                                goto exitttttt;
                            }
                        }
                    }
                    else if(stretch.Name == "stretch_10") {
                        if(Wii_TV.Name == "w480p") {
                            if(Wii_Aspect.Name == "wii_43") {
                                vyska = (UInt16)((vstup_vyska * 640) / vstup_sirka * 1.1);
                                if(vstup_vyska <= 480) {
                                    res = "640:-1";
                                    res_double = "1280:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 480) / vstup_vyska);
                                    res = sirka + ":480";
                                    res_double = sirka * 2 + ":960";
                                }
                            }
                            else if(Wii_Aspect.Name == "wii_169") {
                                vyska = (UInt16)((vstup_vyska * 720) / vstup_sirka * 1.1);
                                if(vstup_vyska <= 480) {
                                    res = "720:-1";
                                    res_double = "1440:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 480) / vstup_vyska);
                                    res = sirka + ":480";
                                    res_double = sirka * 2 + ":960";
                                }
                            }
                            else {
                                message_error("error occured at wii 480p aspect, 10% stretch");
                                goto exitttttt;
                            }
                        }
                        else if(Wii_TV.Name == "w576p") {
                            if(Wii_Aspect.Name == "wii_43") {
                                vyska = (UInt16)((vstup_vyska * 640) / vstup_sirka * 1.1);
                                if(vstup_vyska <= 576) {
                                    res = "640:-1";
                                    res_double = "1280:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 576) / vstup_vyska);
                                    res = sirka + ":576";
                                    res_double = sirka * 2 + ":1152";
                                }
                            }
                            else if(Wii_Aspect.Name == "wii_169") {
                                vyska = (UInt16)((vstup_vyska * 720) / vstup_sirka * 1.1);
                                if(vstup_vyska <= 576) {
                                    res = "720:-1";
                                    res_double = "1440:-1";
                                }
                                else {
                                    sirka = (UInt16)((vstup_sirka * 576) / vstup_vyska);
                                    res = sirka + ":576";
                                    res_double = sirka * 2 + ":1152";
                                }
                            }
                            else {
                                message_error("error occured at wii 576i aspect, 10% stretch");
                                goto exitttttt;
                            }
                        }
                        else {
                            message_error("error occured at wii tv out selection");
                            goto exitttttt;
                        }
                    }
                    if(Wii_framerate.Name == "wii_6050") {
                        if(Wii_TV.Name == "w480p") framerate = 60;
                        else if(Wii_TV.Name == "w576p") framerate = 50;
                        else message_error("error occured at wii tv out selection (resolution w480p)");
                    }
                    else if(Wii_framerate.Name == "wii_3025") {
                        if(Wii_TV.Name == "w480p") framerate = 30;
                        else if(Wii_TV.Name == "w576p") framerate = 25;
                        else message_error("error occured at wii tv out selection (resolution w480p)");
                    }
                    else message_error("error occured at wii framerate selection");
                    exitttttt:;
                    debug_textbox.Text = "res: " + res + "\n";
                    debug_textbox.Text += "resd: " + res_double + "\n";
                    debug_textbox.Text += "framerate: " + framerate + "\n";
                    debug_textbox.Text += "codec: " + codec + "\n";
                    string scale = " ";
                    switch(filtr.Name) {
                        case "scale_linear":
                            scale = " -vf scale=" + res + ":flags=lanczos ";
                            break;
                        case "scale_nearest":
                            scale = " -vf scale=" + res + ":flags=neighbor ";
                            break;
                        case "scale_mix":
                            scale = " -vf scale=" + res_double + ":flags=lanczos,scale=" + res + ":flags=neighbor ";
                            break;
                            
                    }
                    debug_textbox.Text += "scale: " + scale + "\n";
                    ffmpeg.StartInfo.FileName = "cmd.exe";
                    ffmpeg.StartInfo.Arguments = "/k " + "ffmpeg -y -i \"" + vstup + "\" -r " + framerate.ToString() + " " + scale + argumenty + output + " \"" + cesta + "\\" + outputnazev + ".mp4\" " + "&& ping 1.1.1.1 -n 1 && exit 1";
                    debug_textbox.Text += ffmpeg.StartInfo.Arguments;
                    //ffmpeg.StartInfo.Arguments = "/k" + "echo " + vf + threed + codec;
                    //-hide_banner -v warning -stats
                    ffmpeg.Start();
                    ffmpeg.WaitForExit();
                    tadasound.Play();
                }
            }
            else message_error("Error: 3DS/Wii mode not selected!");
            skipaa:;
            Enabled = true;
            //handle.Set();
        }
        private void ds3dshow() {
            if(ds_vf_3d.Checked) {
                ds_3dformat_leftright.Enabled = true;
                ds_3dformat_swap.Enabled = true;
                ds_3dformat_updown.Enabled = true;
            }
            else {
                ds_3dformat_leftright.Enabled = false;
                ds_3dformat_swap.Enabled = false;
                ds_3dformat_updown.Enabled = false;
            }
        }
        private void button1_Click(object sender, EventArgs e) {
            test(null, null);
            openFileDialog1.InitialDirectory = "%userprofile%\\Videos";
            if(openFileDialog1.ShowDialog() == DialogResult.OK) {
                textBox1.Text = openFileDialog1.FileName;
                vstup = openFileDialog1.FileName;
                outputnazev = "3ds_" + Path.GetFileNameWithoutExtension(vstup);
                cesta = Path.GetDirectoryName(vstup);
            }
        }

        private void ds_vf_standard_CheckedChanged(object sender, EventArgs e) {
            ds3dshow();
        }

        private void ds_vf_3d_CheckedChanged(object sender, EventArgs e) {
            ds3dshow();
        }

        private void ds_vf_horihd_CheckedChanged(object sender, EventArgs e) {
            ds3dshow();
        }
        private void test(object sender, EventArgs e) {
            commandsound.Play();
        }

        private void version_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            System.Diagnostics.Process.Start("https://gbatemp.net/threads/nintendo-video-convertor-video-convertor-for-3ds-and-wii.622972");
        }
        
        private async void button2_Click(object sender, EventArgs e) {
            Enabled = false;
            //create new queue
            var queue = new Queue<string>();
            if(cesta != null) {
                //add all files in directory "cesta" to listBox1
                listBox1.Items.Clear();
                foreach(var file in Directory.GetFiles(cesta)) {
                    listBox1.Items.Add(file);
                    queue.Enqueue(file);
                }
            }
            else message_error("Musis vybrat soubor pro konvertovani složky");
            while(queue.Count != 0) {
                vstup = queue.Dequeue();
                outputnazev = "3ds_" + Path.GetFileNameWithoutExtension(vstup);
                cesta = Path.GetDirectoryName(vstup);
                woomy(null, null);
                listBox2.Items.Add(outputnazev);
            }
            Enabled = true;
        }
    }
    public static class TextBoxWatermarkExtensionMethod {
        private const uint ECM_FIRST = 0x1500;
        private const uint EM_SETCUEBANNER = ECM_FIRST + 1;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, uint wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);

        public static void SetWatermark(this TextBox textBox, string watermarkText) {
            SendMessage(textBox.Handle, EM_SETCUEBANNER, 0, watermarkText);
        }

    }
}
